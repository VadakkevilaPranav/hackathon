// src/supabase.js
// ⚠️ Replace with your own Supabase project credentials
// Go to: https://supabase.com → Your Project → Settings → API

import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'YOUR_SUPABASE_URL'           // e.g. https://xyzxyz.supabase.co
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY' // the long public anon key

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
